import java.util.Scanner;
import java.io.*;
import java.io.FileNotFoundException;
import java.lang.Integer;
import java.util.Arrays;
import java.lang.Math;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.stream.IntStream;
import java.util.concurrent.TimeUnit;

/**
 * Provides an implementation of the Intro to Algorithms Coding Assignment using
 * 4 given algorithms.
 *
 * phw_input.txt must be in the workspace folder when running.
 *
 * @author Abigail Taylor aet0059@auburn.edu
 * @author Laura Wilson lgw0020@auburn.edu
 */

public class Main {

   public static void main(String[] args) throws Exception {
      int[] arr = new int[10];
      int output1 = 0;
      int output2 = 0;
      int output3 = 0;
      int output4 = 0;

      Scanner readFile = new Scanner(new File("phw_input.txt"));
      readFile.useDelimiter(",");
      int i = 0;
      while (readFile.hasNext()) {
         if (i == 10) {
            throw new TooManyArgumentsException("Input array can only contain 10 elements!");
         }

         String nextToken = readFile.next().trim();
         try {
            arr[i] = Integer.parseInt(nextToken);
         } catch (NumberFormatException e) {
            System.err.println("Error parsing integer from input: " + nextToken);
         }
         i++;
      }
      readFile.close();
      //Print input array
      System.out.println("For given array: " + Arrays.toString(arr));
      
      //Print output1
      output1 = alg_1(arr);
      System.out.println("algorithm-1: " + output1);
      
      //Print output2
      output2 = alg_2(arr);
      System.out.println("algorithm-2: " + output2);
      
      //Print output3
      output3 = maxSum(arr, 0, 9);
      System.out.println("algorithm-3: " + output3);
      
      //Print output4
      output4 = alg_4(arr);
      System.out.println("algorithm-4: " + output4);

      Random random = new Random();

      int randArr[][] = new int[19][];
      int tempLength = 10;
      for (int j = 0; j < 19; j++) {
         randArr[j] = generateRandomArray(tempLength, random);
         tempLength += 5;
      }

      long outputArr[][] = new long[19][8];
      long[] tempArr = new long[4];
      for (int x = 0; x < 19; x++) {
         tempArr = calcAlgTime(randArr[x]);
         outputArr[x][0] = tempArr[0];
         outputArr[x][1] = tempArr[1];
         outputArr[x][2] = tempArr[2];
         outputArr[x][3] = tempArr[3];
      }

      //Time Complexities
      for (int y = 0; y < 19; y++) {
         int n = randArr[y].length;
         outputArr[y][4] = (long)Math.ceil((7.0*(n^3)/6.0) + (5.0*(n^2)/2) + (3.0*n) + 2);
         outputArr[y][5] = (long)Math.ceil(((n^3)/2.0) + (3.0*(n^2)/2) + (3.0*n) + 2);
         outputArr[y][6] = (long)Math.ceil(n * (Math.log(n) / Math.log(2)));
         outputArr[y][7] = (long)Math.ceil((n^2) + n + 1);
      }

      // Displaying the values of 2D Jagged array
      System.out.println("Contents of 2D Jagged Array");
      for (int k = 0; k < outputArr.length; k++) {
         for (int l = 0; l < outputArr[k].length; l++)
            System.out.print(outputArr[k][l] + " ");
         System.out.println();
      }
      try {
         BufferedWriter bw = new BufferedWriter(new FileWriter("taylor_abigail_wilson_output.txt"));
         bw.write(",algorithm-1,algorithm-2,algorithm-3,algorithm-4,T1(n),T2(n),T3(n),T4(n)");
         bw.newLine();
         for (int m = 0; m < outputArr.length; m++) {
            for (int k = 0; k < outputArr[m].length; k++) {
               bw.write("," + outputArr[m][k]);
            }
            bw.newLine();
         }
         bw.flush();
      } catch (IOException e) {}

      // finding complexities
      for (int y = 0; y < 19; y++) {
         int n = randArr[y].length;
         outputArr[y][4] = (long)Math.ceil((7.0*(n^3)/6.0) + (5.0*(n^2)/2) + (3.0*n) + 2);
         outputArr[y][5] = (long)Math.ceil(((n^3)/2.0) + (3.0*(n^2)/2) + (3.0*n) + 2);
         outputArr[y][6] = (long)Math.ceil(n * (Math.log(n) / Math.log(2)));
         outputArr[y][7] = (long)Math.ceil((n^2) + n + 1);
      }
   }
   
   //ALGORITHM 1
   public static int alg_1(int[] X) {
      int maxSoFar = 0;
      for (int L = 0; L < X.length; L++) {
         for (int U = L; U < X.length; U++) {
            int sum = 0;
            for (int I = L; I < U + 1; I++) {
               sum = sum + X[I];
            }
            maxSoFar = Math.max(maxSoFar, sum);
         }
      }
      return maxSoFar;
   }
   
   //ALGORITHM 2
   public static int alg_2(int[] X) {
      int maxSoFar = 0;
      for (int L = 0; L < X.length; L++) {
         int sum = 0;
         for (int U = L; U < X.length; U++) {
            sum = sum + X[U];
            maxSoFar = Math.max(maxSoFar, sum);
         }
      }
      return maxSoFar;
   }
   
   //ALGORITHM 3 maxSum(recursive)
   public static int maxSum(int[] X, int L, int U) {
      if (L > U) {
         return 0;
      }
      if (L == U) {
         return Math.max(0, X[L]);
      }
      int M = (L + U)/2;
      int sum = 0;
      int maxToLeft = 0;
      for (int I = M; I > L - 1; I--) {
         sum = sum + X[I];
         maxToLeft = Math.max(maxToLeft, sum);
      }

      sum = 0;
      int maxToRight = 0;
      for (int I = M+1; I < U + 1; I++) {
         sum = sum + X[I];
         maxToRight = Math.max(maxToRight, sum);
      }
      int maxCrossing = maxToLeft + maxToRight;

      int maxInA = maxSum(X, L, M);
      int maxInB = maxSum(X, M+1, U);
      return Math.max(maxCrossing, Math.max(maxInA, maxInB));
   }
   
   //ALGORITHM 4
   public static int alg_4(int[] X) {
      int maxSoFar = 0;
      int maxEndingHere = 0;
      for (int I = 0; I < X.length; I++) {
         maxEndingHere = Math.max(0, maxEndingHere + X[I]);
         maxSoFar = Math.max(maxSoFar, maxEndingHere);
      }
      return maxSoFar;
   }
   
   //Random array generated
   public static int[] generateRandomArray(int size, Random random) {
      ArrayList<Integer> list = new ArrayList<Integer>(size);
      
      for (int i = 0; i < size; i++) {
         list.add(random.nextInt(101 + 100) - 100);
      }
      int[] arr = list.stream().mapToInt(i -> i).toArray();
      return arr;
   }
   
   //time in nanonseconds
   public static long[] calcAlgTime(int[] arr) {
      long startAlg1, startAlg2, startAlg3, startAlg4, endAlg1, endAlg2, endAlg3, endAlg4,
              avgAlg1, avgAlg2, avgAlg3, avgAlg4;
      long[] avgTimes = new long[4];

      startAlg1 = System.nanoTime();
      for (int i = 0; i < 500; i++) {
         alg_1(arr);
      }
      endAlg1 = System.nanoTime();
      avgAlg1 = (endAlg1-startAlg1) / 500;
      avgTimes[0] = avgAlg1;

      startAlg2 = System.nanoTime();
      for (int i = 0; i < 500; i++) {
         alg_2(arr);
      }
      endAlg2 = System.nanoTime();
      avgAlg2 = (endAlg2-startAlg2) / 500;
      avgTimes[1] = avgAlg2;

      startAlg3 = System.nanoTime();
      for (int i = 0; i < 500; i++) {
         maxSum(arr, 0, arr.length-1);
      }
      endAlg3 = System.nanoTime();
      avgAlg3 = (endAlg3-startAlg3) / 500;
      avgTimes[2] = avgAlg3;

      startAlg4 = System.nanoTime();
      for (int i = 0; i < 500; i++) {
         alg_4(arr);
      }
      endAlg4 = System.nanoTime();
      avgAlg4 = (endAlg4-startAlg4) / 500;
      avgTimes[3] = avgAlg4;

      return avgTimes;
   }
}

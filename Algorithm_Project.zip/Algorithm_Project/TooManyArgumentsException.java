/**
* This program creates a new exception that describes a wrong input
* category.
*
* @author abigail taylor laura wilson
* @version 21 july 2023
*/
public class TooManyArgumentsException extends Exception { 
   public TooManyArgumentsException(String errorMessage) {
      super("For number: " + errorMessage);
   }
}
Matthew Finlay
Files:abigail_taylor_laura_wilson.txt
	Main.java
	Taylor_Wilson_Charts.pdf
	phw_input.txt
	TooManyArgumentsException.java

Abigail wrote project file. Laura created output files and time complexity charts
	
I certify that I wrote the code I am submitting. I did not copy whole or parts of it from another student or have another person write the code for me. Any code I am reusing in my program is clearly marked as such with its source clearly identified in comments.